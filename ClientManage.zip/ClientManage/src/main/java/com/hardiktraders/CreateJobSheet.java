package com.hardiktraders;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

@WebServlet("/createsheet")
@MultipartConfig(location = "C:\\Users\\PARAS\\OneDrive\\Desktop\\InternShala\\ClientManage\\Upload", maxFileSize = 1048576, // 1
																																// MB
		maxRequestSize = 2097152, // 2 MB
		fileSizeThreshold = 1048576 // 1 MB
)
public class CreateJobSheet extends HttpServlet {
	private static final String UPLOAD_DIR = "C:\\Users\\PARAS\\OneDrive\\Desktop\\InternShala\\ClientManage\\Upload\\";
	private static final String DB_URL = "jdbc:postgresql://localhost:5432/hardiktraders";
	private static final String DB_USERNAME = "postgres";
	private static final String DB_PASSWORD = "root";
	private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd");

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String clientName = req.getParameter("cn");
		String contact = req.getParameter("contactInfoo");
		String receivedDateStr = req.getParameter("receivedDatee");
		Date receivedDate = parseDate(receivedDateStr);
		String inventoryReceived = req.getParameter("inventoryReceivedd");
		Part filePart = req.getPart("uploadInventoryy");
		String fileName = "";

		if (filePart != null) {
			fileName = Paths.get(filePart.getSubmittedFileName()).getFileName().toString();
			InputStream fileContent = filePart.getInputStream();

			// Store file on server
			Files.createDirectories(Paths.get(UPLOAD_DIR)); // Create directory if it doesn't exist
			Files.copy(fileContent, Paths.get(UPLOAD_DIR + fileName), StandardCopyOption.REPLACE_EXISTING);
		}

		String reportedIssues = req.getParameter("reportedIssuess");
		String clientNotes = req.getParameter("clientNotess");
		String assignedTechnician = req.getParameter("assignedTechniciann");
		String deadlineStr = req.getParameter("deadlinee");
		Date deadline = parseDate(deadlineStr);
		long estimatedAmount = Long.parseLong(req.getParameter("estimatedAmountt"));
		String status = req.getParameter("statuss");
		String clientId = generateClientId(clientName, contact);
		
		System.out.println("Received parameters:");
        System.out.println("Client Name: " + clientName);
        System.out.println("Contact: " + contact);
        System.out.println("Received Date: " + receivedDateStr);
        System.out.println("Inventory Received: " + inventoryReceived);
        System.out.println("Reported Issues: " + reportedIssues);
        System.out.println("Client Notes: " + clientNotes);
        System.out.println("Assigned Technician: " + assignedTechnician);
        System.out.println("Deadline: " + deadlineStr);
        System.out.println("Estimated Amount: " + estimatedAmount);
        System.out.println("Status: " + status);
        System.out.println("Received Date: " + receivedDate);
        System.out.println("Deadline: " + deadline);


        try {
			Class.forName("org.postgresql.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
     // JDBC code to insert data into PostgreSQL database
        try (	
        		Connection conn = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD)) {
            System.out.println("Connected to database");

            String query = "INSERT INTO job_sheets (client_id,client_name, contact_info, received_date, inventory_received, file_name, reported_issues, client_notes, assigned_technician, deadline, estimated_amount, status) VALUES (?,?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(query);
            
            pstmt.setString(1, clientId);
            pstmt.setString(2, clientName);
            pstmt.setString(3, contact);
            pstmt.setDate(4, new java.sql.Date(receivedDate.getTime()));
            pstmt.setString(5, inventoryReceived);
            pstmt.setString(6, fileName);
            pstmt.setString(7, reportedIssues);
            pstmt.setString(8, clientNotes);
            pstmt.setString(9, assignedTechnician);
            pstmt.setDate(10, new java.sql.Date(deadline.getTime()));
            pstmt.setLong(11, estimatedAmount);
            pstmt.setString(12, status);

            System.out.println("Executing query: " + query);
            pstmt.executeUpdate();
            System.out.println("Data inserted successfully");
            
            try {
            	resp.sendRedirect(req.getContextPath() + "/homepage");
            } catch (IOException e) {
                System.out.println("Error redirecting to HomePage.html: " + e.getMessage());
                e.printStackTrace();
            }

        } catch (SQLException e) {
            System.out.println("Error inserting data into database: " + e.getMessage());
            e.printStackTrace();
            resp.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error inserting data into database");
            return;
        }
    }


	private Date parseDate(String dateStr) {
		try {
			return DATE_FORMAT.parse(dateStr);
		} catch (ParseException e) {
			throw new RuntimeException("Invalid date format. Expected yyyy-MM-dd", e);
		}
	}
	
	private String generateClientId(String clientName, String contact) {
		
		String firstName = clientName.split(" ")[0];
		
		String lastFourDigits = contact.substring(contact.length() - 4);
		
		return firstName + lastFourDigits;
	}

}
