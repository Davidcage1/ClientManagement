package com.hardiktraders;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/viewJobSheet")
public class ViewJobSheet extends HttpServlet {
    private static final String DB_URL = "jdbc:postgresql://localhost:5432/hardiktraders";
    private static final String DB_USERNAME = "postgres";
    private static final String DB_PASSWORD = "root";

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String jobId = req.getParameter("id");
        
        System.out.println(jobId);

        try {
            Class.forName("org.postgresql.Driver");
        } catch (ClassNotFoundException e) {
            System.out.println("Error loading PostgreSQL driver: " + e.getMessage());
            e.printStackTrace();
        }

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD)) {
            System.out.println("Connected to database");

            String query = "SELECT * FROM job_sheets WHERE id = ?";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, Integer.parseInt(jobId));  // Set the job ID in the query
            ResultSet resultSet = pstmt.executeQuery();

            if (resultSet.next()) {
                // Pass data to the JSP page
                req.setAttribute("clientName", resultSet.getString("client_name"));
                req.setAttribute("contactInfo", resultSet.getString("contact_info"));
                req.setAttribute("receivedDate", resultSet.getDate("received_date"));
                req.setAttribute("inventoryReceived", resultSet.getString("inventory_received"));
                req.setAttribute("fileName", resultSet.getString("file_name"));

                req.setAttribute("reportedIssues", resultSet.getString("reported_issues"));
                req.setAttribute("clientNotes", resultSet.getString("client_notes"));
                req.setAttribute("assignedTechnician", resultSet.getString("assigned_technician"));
                req.setAttribute("estimatedAmount", resultSet.getLong("estimated_amount"));
                req.setAttribute("deadline", resultSet.getDate("deadline"));
                req.setAttribute("status", resultSet.getString("status"));
            }

            req.getRequestDispatcher("/viewJobSheet.jsp").forward(req, resp);

        } catch (SQLException e) {
            System.out.println("Error retrieving data from database: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
