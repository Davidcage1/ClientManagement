package com.hardiktraders;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/homepage")

public class HomePage extends HttpServlet {
    private static final String DB_URL = "jdbc:postgresql://localhost:5432/hardiktraders";
    private static final String DB_USERNAME = "postgres";
    private static final String DB_PASSWORD = "root";

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try {
            Class.forName("org.postgresql.Driver");
        } catch (ClassNotFoundException e) {
            System.out.println("Error loading PostgreSQL driver: " + e.getMessage());
            e.printStackTrace();
        }

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD)) {
            System.out.println("Connected to database");

            String query = "SELECT * FROM job_sheets";
            PreparedStatement pstmt = conn.prepareStatement(query);
            ResultSet resultSet = pstmt.executeQuery();

            StringBuilder tableData = new StringBuilder();
            while (resultSet.next()) {
                tableData.append("<tr>");
                tableData.append("<td>").append(resultSet.getInt("id")).append("</td>");
                tableData.append("<td>").append(resultSet.getString("client_id")).append("</td>");
                tableData.append("<td>").append(resultSet.getString("client_name")).append("</td>");
                tableData.append("<td>").append(resultSet.getString("contact_info")).append("</td>");
                tableData.append("<td>").append(resultSet.getDate("received_date")).append("</td>");
                tableData.append("<td>").append(resultSet.getString("inventory_received")).append("</td>");
                tableData.append("<td>").append(resultSet.getString("reported_issues")).append("</td>");
                tableData.append("<td>").append(resultSet.getString("client_notes")).append("</td>");
                tableData.append("<td>").append(resultSet.getString("assigned_technician")).append("</td>");
                tableData.append("<td>").append(resultSet.getLong("estimated_amount")).append("</td>");
                tableData.append("<td>").append(resultSet.getDate("deadline")).append("</td>");
                tableData.append("<td>").append(resultSet.getString("status")).append("</td>");
                tableData.append("<td class=\"action-buttons\">");
                tableData.append("<button class=\"view-button\" onclick=\"window.location.href='viewJobSheet?id=" + resultSet.getInt("id") + "'\">View</button>");

                tableData.append("<button class=\"edit-button\" onclick=\"window.location.href='editJobSheet?id=").append(resultSet.getInt("id")).append("'\">Edit</button>");
                tableData.append("<form action=\"deleteJobSheet\" method=\"post\" style=\"display:inline;\">");
                tableData.append("<input type=\"hidden\" name=\"id\" value=\"").append(resultSet.getInt("id")).append("\">");
                tableData.append("<button type=\"submit\" class=\"delete-button\">Delete</button>");
                tableData.append("</form>");

                tableData.append("</td>");
                tableData.append("</tr>");
            }

            req.setAttribute("tableData", tableData.toString());
            req.getRequestDispatcher("/HomePage.jsp").forward(req, resp);
        } catch (SQLException e) {
            System.out.println("Error retrieving data from database: " + e.getMessage());
            e.printStackTrace();
        }
    }
}