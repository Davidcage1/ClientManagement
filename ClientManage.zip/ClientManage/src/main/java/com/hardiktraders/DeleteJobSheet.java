package com.hardiktraders;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/deleteJobSheet")
public class DeleteJobSheet extends HttpServlet {
    private static final String DB_URL = "jdbc:postgresql://localhost:5432/hardiktraders";
    private static final String DB_USERNAME = "postgres";
    private static final String DB_PASSWORD = "root";

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String jobId = req.getParameter("id");  // Get the job sheet ID from the form
        
        try {
			Class.forName("org.postgresql.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

        if (jobId != null) {
            try (Connection conn = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD)) {
                String deleteQuery = "DELETE FROM job_sheets WHERE id = ?";
                PreparedStatement pstmt = conn.prepareStatement(deleteQuery);
                pstmt.setInt(1, Integer.parseInt(jobId));
                int rowsAffected = pstmt.executeUpdate();

                if (rowsAffected > 0) {
                    System.out.println("Job Sheet deleted successfully.");
                } else {
                    System.out.println("Failed to delete Job Sheet. ID not found.");
                }

               
                resp.sendRedirect("homepage");
                
            } catch (SQLException e) {
                System.out.println("Error deleting Job Sheet: " + e.getMessage());
                e.printStackTrace();
                resp.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error deleting Job Sheet.");
            }
        } else {
            System.out.println("Job ID is null, cannot delete.");
            resp.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid Job Sheet ID.");
        }
    }
}
