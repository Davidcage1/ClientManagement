package com.hardiktraders;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/updateJobSheet")
public class UpdateJobSheetServlet extends HttpServlet {
	private static final String DB_URL = "jdbc:postgresql://localhost:5432/hardiktraders";
	private static final String DB_USERNAME = "postgres";
	private static final String DB_PASSWORD = "root";

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		HttpSession session = req.getSession();
	    Integer id = (Integer) session.getAttribute("jobId");
		
		
		String clientName = req.getParameter("clientName");
		String contactInfo = req.getParameter("contactInfo");
		String receivedDateStr = req.getParameter("receivedDate");
		String inventoryReceived = req.getParameter("inventoryReceived");
		String reportedIssues = req.getParameter("reportedIssues");
		String clientNotes = req.getParameter("clientNotes");
		String assignedTechnician = req.getParameter("assignedTechnician");
		long estimatedAmount = Long.parseLong(req.getParameter("estimatedAmount"));
		System.out.println();
		String deadlineStr = req.getParameter("deadline");
		String status = req.getParameter("status");

		try {
			Class.forName("org.postgresql.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

		try (Connection conn = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD)) {
			String query = "UPDATE job_sheets SET client_name = ?, contact_info = ?, received_date = ?, inventory_received = ?, reported_issues = ?, client_notes = ?, assigned_technician = ?, estimated_amount = ?, deadline = ?, status = ? WHERE id = ?";
			PreparedStatement pstmt = conn.prepareStatement(query);

			pstmt.setString(1, clientName);
			pstmt.setString(2, contactInfo);
			pstmt.setDate(3, java.sql.Date.valueOf(receivedDateStr));
			pstmt.setString(4, inventoryReceived);
			pstmt.setString(5, reportedIssues);
			pstmt.setString(6, clientNotes);
			pstmt.setString(7, assignedTechnician);
			pstmt.setLong(8, estimatedAmount);
			pstmt.setDate(9, java.sql.Date.valueOf(deadlineStr));
			pstmt.setString(10, status);
			pstmt.setInt(11, id);

			pstmt.executeUpdate();

			resp.sendRedirect(req.getContextPath() + "/homepage");
		} catch (SQLException e) {
			e.printStackTrace();
			resp.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error updating job sheet");
		}
	}
}
