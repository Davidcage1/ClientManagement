package com.hardiktraders;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/downloadFile")
public class FileDownloadServlet extends HttpServlet {
    private static final String UPLOAD_DIR = "C:\\Users\\PARAS\\OneDrive\\Desktop\\InternShala\\ClientManage\\Upload\\";  // The directory where files are stored

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // Get the file name from the request
        String fileName = req.getParameter("fileName");

        if (fileName == null || fileName.equals("")) {
            resp.getWriter().println("File name can't be null or empty");
            return;
        }

        // Create a file object for the requested file
        File file = new File(UPLOAD_DIR + fileName);

        // Check if the file exists
        if (!file.exists()) {
            resp.getWriter().println("File not found");
            return;
        }

        // Set the response headers to indicate file download
        resp.setContentType(getServletContext().getMimeType(file.getName()));
        resp.setContentLength((int) file.length());
        resp.setHeader("Content-Disposition", "attachment; filename=\"" + fileName + "\"");

        // Serve the file
        try (FileInputStream in = new FileInputStream(file); OutputStream out = resp.getOutputStream()) {
            byte[] buffer = new byte[4096];
            int bytesRead;
            while ((bytesRead = in.read(buffer)) != -1) {
                out.write(buffer, 0, bytesRead);
            }
        }
    }
}
